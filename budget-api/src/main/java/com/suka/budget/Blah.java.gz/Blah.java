package com.suka.budget;

public class Blah {

}
