package com.suka.budget;

/** 
 * Represents an account within a portfolio.
 * @author Joshua Mark Rutherford
 */
public class Account extends UuidPersistent {

	/**
	 * Gets the name of this account.
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Sets the name of this account.
	 * @param value the name
	 */
	public void setName(String value) {
		this.name = value;
	}
	
	/**
	 * Gets the description of this account.
	 * @return the description
	 */
	public String getDescription() {
		return this.description;
	}
	
	/**
	 * Sets the description of this account.
	 * @param value the description
	 */
	public void setDescription(String value) {
		this.description = value;
	}
	
	private String name;
	private String description;
	
}
