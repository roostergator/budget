package com.suka.budget;

/**
 * Defines the interface for all classes that are persisted.
 * @author Joshua Mark Rutherford
 */
public interface Persistent {

	/**
	 * Gets the id of this persistent.
	 * @return the id
	 */
	public String getId();
	
	/**
	 * Sets the id of this persistent.
	 * @param value the id
	 */
	public void setId(String value);
	
	/**
	 * Gets the version of this persistent.
	 * @return the version
	 */
	public long getVersion();
	
	/**
	 * Sets the version of this persistent.
	 * @param version the version
	 */
    public void setVersion(long version);
	
}
