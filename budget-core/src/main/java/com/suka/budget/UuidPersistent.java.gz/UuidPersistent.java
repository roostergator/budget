package com.suka.budget;

import java.util.UUID;

/**
 * Provides an abstract base class for all classes implement the Persisted interface using a universally unique identifier (UUID).
 * @author Joshua Mark Rutherford
 */
public class UuidPersistent implements Persistent {

	/**
	 * Initializes a new instance of the com.suka.budget.UuidPersistent class.
	 */
	public UuidPersistent() {
		this.id = UUID.randomUUID().toString();
	}
	
	/**
	 * {@inheritDoc}
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * {@inheritDoc}
	 */
	public void setId(String value) {
		this.id = value;
	}

	/**
	 * {@inheritDoc}
	 */
	public long getVersion() {
		return this.version;
	}

	/**
	 * {@inheritDoc}
	 */
	public void setVersion(long value) {
		this.version = value;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object object) {
        if (this == object) {
        	return true;
        } else if (object == null || !(object instanceof Persistent)) {
            return false;
        } else {
        	Persistent persistent = (Persistent)object;
        	return (this.id == null) ? false : this.id.equals(persistent.getId());
        }
    }
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
        return (this.id != null) ? this.id.hashCode() : super.hashCode();
    }
	
	/**
	 * {@inheritDoc}
	 */
	@Override
    public String toString() {
    	return this.getClass().getName() + "[id=" + this.id + "]";
    }
	
	private String id;
	private long version;
	
}
