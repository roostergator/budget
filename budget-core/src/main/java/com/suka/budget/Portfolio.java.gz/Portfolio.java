package com.suka.budget;

public class Portfolio extends UuidPersistent {

	
	
}
