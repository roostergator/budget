package com.suka.budget;

import java.math.BigDecimal;

/**
 * Represents a transaction that debits from one account and credits to one or more accounts.
 * @author Joshua
 *
 */
public class Transaction {
	
	public BigDecimal getAmount() {
		return this.amount;
	}
	
	public void setAmount(BigDecimal value) {
		this.amount = value;
	}
	
	public Account getCreditAccount() {
		return this.creditAccount;
	}
	
	public void setCreditAccount(Account value) {
		this.creditAccount = value;
	}
	
	public Account getDebitAccount() {
		return this.debitAccount;
	}
	
	public void setDebitAccount(Account value) {
		this.debitAccount = value;
	}
	
	private BigDecimal amount;
	private Account creditAccount;
	private Account debitAccount;
	
}
